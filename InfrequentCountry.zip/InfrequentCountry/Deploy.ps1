$today=Get-Date -Format "MM-dd-yyyy"
$deploymentName="InfrequentCountryTriageLogicApp_"+"$today"

Import-Module Az.Resources
New-AzResourceGroupDeployment -ResourceGroupName Dev -TemplateFile .\InfrequentCountryTriage.template.json -TemplateParameterFile "C:\GitHub\parameters\mcasToken.parameters.json" -Name $deploymentName -Verbose